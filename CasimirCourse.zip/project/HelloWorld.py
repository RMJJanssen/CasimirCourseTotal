#This python scripts says hello to the world
print("Hello World!")

def ReplaceHello(String)
     String.Replace('Hello','Hi')
     return String

