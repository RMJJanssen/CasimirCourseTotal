# Yes, it's in Python.
print("Hello world")
