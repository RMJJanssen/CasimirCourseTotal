This is my project. It is going to do many things, but I'm not yet sure what exactly.

Probably, I will implement something using Python! 
It will say "hello world" and then something else.
