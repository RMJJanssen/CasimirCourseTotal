class Resonator(object):
    
    def __init__(self, fres, frequency_unit='GHz'):
        """Store all parameters of a given resonator
        
        Parameters:
        ===========
        fres: value of the resonance frequency
        frequency_unit: unit of the frequency
        
        """
        self.fres = fres
        self.frequency_unit='GHz'